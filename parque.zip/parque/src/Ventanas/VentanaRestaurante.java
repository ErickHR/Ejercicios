/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ventanas;

import Lista.*;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import zonaTematica.Restaurante;

/**
 *
 * @author PROPIETARIO
 */
public class VentanaRestaurante extends javax.swing.JFrame {

    /**
     * Creates new form VentanaRestaurante
     */
    VentanaPrincipal ventanaPrincipal;
    ListaZonaTematica listaZonaTematica;
    ListaRestaurante listaRestaurante;
    String arregloResaturante[] = new String[6];
    String btn;
    int fila;
    DefaultTableModel modelo;
    public VentanaRestaurante(ListaZonaTematica lista, VentanaPrincipal ventanaPrincipal) {
        initComponents();
        this.ventanaPrincipal = ventanaPrincipal;
        listaZonaTematica = lista;
        
        modelo = (DefaultTableModel) tbRestaurante.getModel();
        estadoTxt(false);
        listarCb();
        listarTabla();
        estadoBtnGuardar(false);
        this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    }
/*
    public boolean unicoNombreDniEditar(){
        int cont = 0;
        for(NodoZonaTematica auxNodoZonaTematica = listaZonaTematica.getInicio(); auxNodoZonaTematica != null; auxNodoZonaTematica = auxNodoZonaTematica.getSiguiente()){
            cont = 0;
            for(NodoRestaurante auxRestaurante = auxNodoZonaTematica.getRestaurante().getInicio(); auxRestaurante != null; auxRestaurante = auxRestaurante.getSiguiente()){
                if((auxRestaurante.getRestaurante().getIdRestaurante().equals(txtIdRestaurante.getText()) || auxRestaurante.getRestaurante().getIdRestaurante().equals(txtNombreRestaurante.getText()))&& fila != cont ){
                    JOptionPane.showMessageDialog(null, "inserte otro Id");
                    return false;
                }
                cont++;
            }
        }
        return true;
    }
*/
    public boolean unicoIdEditar(){
        int filaSeleccionada = 0;
        for(NodoZonaTematica auxNodoZonaTematica = listaZonaTematica.getInicio(); auxNodoZonaTematica != null; auxNodoZonaTematica = auxNodoZonaTematica.getSiguiente()){
            for(NodoRestaurante auxRestaurante = auxNodoZonaTematica.getRestaurante().getInicio(); auxRestaurante != null; auxRestaurante = auxRestaurante.getSiguiente()){
                if(auxRestaurante.getRestaurante().getIdRestaurante().equals(txtIdRestaurante.getText()) && fila != filaSeleccionada ){
                    JOptionPane.showMessageDialog(null, "inserte otro Id");
                    return false;
                }
                filaSeleccionada++;
            }
        }
        return true;
    }
    
    public boolean unicoNombreEditar(){
        int cont = 0;
        for(NodoZonaTematica auxNodoZonaTematica = listaZonaTematica.getInicio(); auxNodoZonaTematica != null; auxNodoZonaTematica = auxNodoZonaTematica.getSiguiente()){
            for(NodoRestaurante auxRestaurante = auxNodoZonaTematica.getRestaurante().getInicio(); auxRestaurante != null; auxRestaurante = auxRestaurante.getSiguiente()){
                if(auxRestaurante.getRestaurante().getIdRestaurante().equals(txtNombreRestaurante.getText()) && fila != cont ){
                    JOptionPane.showMessageDialog(null, "inserte otro nombre");
                    return false;
                }
                cont++;
            }
        }
        return true;
    }

    public boolean unicoId(){
        for(NodoZonaTematica auxNodoZonaTematica = listaZonaTematica.getInicio(); auxNodoZonaTematica != null; auxNodoZonaTematica = auxNodoZonaTematica.getSiguiente())
            for(NodoRestaurante auxRestaurante = auxNodoZonaTematica.getRestaurante().getInicio(); auxRestaurante != null; auxRestaurante = auxRestaurante.getSiguiente())
                if(auxRestaurante.getRestaurante().getIdRestaurante().equals(txtIdRestaurante.getText())){
                    JOptionPane.showMessageDialog(null, "inserte otro Id");
                    return false;
                }
        return true;
    }
    public boolean unicoNombre(){
        for(NodoZonaTematica auxNodoZonaTematica = listaZonaTematica.getInicio(); auxNodoZonaTematica != null; auxNodoZonaTematica = auxNodoZonaTematica.getSiguiente())
            for(NodoRestaurante auxRestaurante = auxNodoZonaTematica.getRestaurante().getInicio(); auxRestaurante != null; auxRestaurante = auxRestaurante.getSiguiente())
                if(auxRestaurante.getRestaurante().getIdRestaurante().equals(txtNombreRestaurante.getText())){
                    JOptionPane.showMessageDialog(null, "inserte otro Nombre");
                    return false;
                }
        return true;
    }
    public void listarCb(){
        for(NodoZonaTematica aux = listaZonaTematica.getInicio(); aux != null; aux = aux.getSiguiente()){
            cbZonaTematica.addItem(aux.getZonaTematica().getNombre());
        }
    }
    public void listarTabla(){
        modelo.setRowCount(0);
        int cantidad = 1;
        for(NodoZonaTematica auxZonaTematica = listaZonaTematica.getInicio(); auxZonaTematica != null; auxZonaTematica = auxZonaTematica.getSiguiente())
            for(NodoRestaurante auxRestaurante = auxZonaTematica.getRestaurante().getInicio(); auxRestaurante != null; auxRestaurante = auxRestaurante.getSiguiente()){
                arregloResaturante[0] = Integer.toString(cantidad);
                arregloResaturante[1] = auxRestaurante.getRestaurante().getIdRestaurante();
                arregloResaturante[2] = auxRestaurante.getRestaurante().getNombre();
                arregloResaturante[3] = auxRestaurante.getRestaurante().getHorario();
                arregloResaturante[4] = Float.toString(auxRestaurante.getRestaurante().getPrecioMedio());
                arregloResaturante[5] = auxZonaTematica.getZonaTematica().getNombre();
                modelo.addRow(arregloResaturante);
                cantidad++;
            }
        
    }
    public void estadoBtnGuardar(boolean booleano){
        btnEditar.setEnabled(!booleano);
        btnEliminar.setEnabled(!booleano);
        btnGuardar.setEnabled(booleano);
        btnNuevo.setEnabled(!booleano);
    }
    public void estadoTxt(boolean booleano){
        txtIdRestaurante.requestFocus();
        txtHorarioRestaurante.setEnabled(booleano);
        txtIdRestaurante.setEnabled(booleano);
        txtNombreRestaurante.setEnabled(booleano);
        txtPrecioMEdio.setEnabled(booleano);
    }
    public void modificarTxt(String id, String nombre, String horario, String precio){
        txtHorarioRestaurante.setText(horario);
        txtIdRestaurante.setText(id);
        txtNombreRestaurante.setText(nombre);
        txtPrecioMEdio.setText(precio);
    }
    public void soloLetras(java.awt.event.KeyEvent evt){
        char validar = evt.getKeyChar();
        if(Character.isDigit(validar))
            evt.consume();
    }
    public void soloNumeros(java.awt.event.KeyEvent evt){
        char validar = evt.getKeyChar();
        if(Character.isLetter(validar))
            evt.consume();
    }
    public boolean listaVacia(){
        if(listaZonaTematica.getInicio().getRestaurante().getInicio() == null){
            JOptionPane.showMessageDialog(null, "Lista vacia");
            return true;
        }
        return false;
    }
    public boolean filaEsMenoUno(){
        fila = tbRestaurante.getSelectedRow();
        if(fila == -1){
            JOptionPane.showMessageDialog(null, "seleccion un elemento de la fila");
            return true;
        }
        return false;
    }
    public boolean txtsObligatoriosVacio(){
        if(txtIdRestaurante.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "inserte id");
            txtIdRestaurante.requestFocus();
            return true;
        }
        if(txtNombreRestaurante.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "inserte Nombre");
            txtNombreRestaurante.requestFocus();
            return true;
        }
        if(txtHorarioRestaurante.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "inserte horario");
            txtHorarioRestaurante.requestFocus();
            return true;
        }
        if(txtPrecioMEdio.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "inserte precio");
            txtPrecioMEdio.requestFocus();
            return true;
        }
        return false;
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtIdRestaurante = new javax.swing.JTextField();
        txtNombreRestaurante = new javax.swing.JTextField();
        txtHorarioRestaurante = new javax.swing.JTextField();
        txtPrecioMEdio = new javax.swing.JTextField();
        btnNuevo = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbRestaurante = new javax.swing.JTable();
        btnEditar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnGuardar = new javax.swing.JButton();
        cbZonaTematica = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosed(java.awt.event.WindowEvent evt) {
                formWindowClosed(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setText("NOMBRE:");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(93, 145, -1, -1));

        jLabel2.setText("HORARIO");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(93, 174, -1, -1));

        jLabel3.setText("PRECIO MEDIO:");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(93, 203, -1, -1));

        jLabel4.setText("ID:");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(93, 116, -1, -1));
        getContentPane().add(txtIdRestaurante, new org.netbeans.lib.awtextra.AbsoluteConstraints(178, 113, 78, -1));

        txtNombreRestaurante.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtNombreRestauranteKeyTyped(evt);
            }
        });
        getContentPane().add(txtNombreRestaurante, new org.netbeans.lib.awtextra.AbsoluteConstraints(178, 142, 78, -1));
        getContentPane().add(txtHorarioRestaurante, new org.netbeans.lib.awtextra.AbsoluteConstraints(178, 171, 78, -1));

        txtPrecioMEdio.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtPrecioMEdioKeyTyped(evt);
            }
        });
        getContentPane().add(txtPrecioMEdio, new org.netbeans.lib.awtextra.AbsoluteConstraints(175, 200, 78, -1));

        btnNuevo.setText("NUEVO");
        btnNuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuevoActionPerformed(evt);
            }
        });
        getContentPane().add(btnNuevo, new org.netbeans.lib.awtextra.AbsoluteConstraints(358, 112, 81, -1));

        tbRestaurante.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "#", "ID", "NOMBRE", "HORARIO", "PRECIO MEDIO", "ZONA TEMATICA"
            }
        ));
        jScrollPane1.setViewportView(tbRestaurante);
        if (tbRestaurante.getColumnModel().getColumnCount() > 0) {
            tbRestaurante.getColumnModel().getColumn(0).setMinWidth(20);
            tbRestaurante.getColumnModel().getColumn(0).setMaxWidth(20);
        }

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 240, 496, 231));

        btnEditar.setText("EDITAR");
        btnEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarActionPerformed(evt);
            }
        });
        getContentPane().add(btnEditar, new org.netbeans.lib.awtextra.AbsoluteConstraints(354, 141, 81, -1));

        btnEliminar.setText("ELIMINAR");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });
        getContentPane().add(btnEliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(354, 170, -1, -1));

        btnGuardar.setText("GUARDAR");
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });
        getContentPane().add(btnGuardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(354, 199, -1, -1));

        getContentPane().add(cbZonaTematica, new org.netbeans.lib.awtextra.AbsoluteConstraints(178, 52, 175, -1));

        jLabel5.setText("Zona Tematica");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(93, 55, 79, -1));

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/Restaurant_3.jpg"))); // NOI18N
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(-6, -30, 510, 510));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnNuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevoActionPerformed
        btn = "NUEVO";
        estadoTxt(true);
        estadoBtnGuardar(true);
    }//GEN-LAST:event_btnNuevoActionPerformed

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
        // TODO add your handling code here:
        if(txtsObligatoriosVacio()) return;
        switch(btn){
            case "NUEVO":
                if(!unicoId() || !unicoNombre()) return;
                listaRestaurante = listaZonaTematica.listaRestaurante(cbZonaTematica.getSelectedItem().toString());
                listaRestaurante.agregarAdelante(new Restaurante(txtIdRestaurante.getText(), txtNombreRestaurante.getText(), txtHorarioRestaurante.getText(), Float.parseFloat(txtPrecioMEdio.getText())));
                break;
            case "EDITAR":
                if(!unicoIdEditar() || !unicoNombreEditar()) return;
                NodoRestaurante auxRestaurante = listaZonaTematica.listaRestaurante(cbZonaTematica.getSelectedItem().toString()).modificar(tbRestaurante.getValueAt(fila, 1).toString());
                auxRestaurante.setRestaurante(new Restaurante(txtIdRestaurante.getText(), txtNombreRestaurante.getText(), txtHorarioRestaurante.getText(), Float.parseFloat(txtPrecioMEdio.getText())));
        }
        
        modificarTxt("", "", "", "");
        estadoTxt(false);
        estadoBtnGuardar(false);
        listarTabla();
        
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void formWindowClosed(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosed
        if(listaZonaTematica.getInicio().getRestaurante() == null) return;
        
        ventanaPrincipal.listarCbRestauranteEspectaculoAtraccion();
        ventanaPrincipal.estadoMenuAgregarCliente(true);
    }//GEN-LAST:event_formWindowClosed

    private void txtNombreRestauranteKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNombreRestauranteKeyTyped
        soloLetras(evt);
    }//GEN-LAST:event_txtNombreRestauranteKeyTyped

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        if(listaVacia()) return;
        if(filaEsMenoUno()) return;
        listaRestaurante = listaZonaTematica.listaRestaurante(cbZonaTematica.getSelectedItem().toString());
        listaRestaurante.eliminar(tbRestaurante.getValueAt(fila, 1).toString());
        
        //listaRestaurante = listaZonaTematica.getInicio().getRestaurante();
        //listaRestaurante.eliminar(tbRestaurante.getValueAt(fila, 1).toString());
        listarTabla();
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarActionPerformed
        if(listaVacia()) return;
        if(filaEsMenoUno())return;
        btn = "EDITAR";
        modificarTxt(tbRestaurante.getValueAt(fila, 1).toString(),
                tbRestaurante.getValueAt(fila, 2).toString(),
                tbRestaurante.getValueAt(fila, 3).toString(),
                tbRestaurante.getValueAt(fila, 4).toString());
        estadoTxt(true);
        estadoBtnGuardar(true);
    }//GEN-LAST:event_btnEditarActionPerformed

    private void txtPrecioMEdioKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtPrecioMEdioKeyTyped
        soloNumeros(evt);
    }//GEN-LAST:event_txtPrecioMEdioKeyTyped

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnEditar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnNuevo;
    private javax.swing.JComboBox<String> cbZonaTematica;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tbRestaurante;
    private javax.swing.JTextField txtHorarioRestaurante;
    private javax.swing.JTextField txtIdRestaurante;
    private javax.swing.JTextField txtNombreRestaurante;
    private javax.swing.JTextField txtPrecioMEdio;
    // End of variables declaration//GEN-END:variables
}
