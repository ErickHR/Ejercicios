
package Ventanas;

import Lista.ListaZonaTematica;
import Lista.ListaAtraccion;
import Lista.NodoAtraccion;
import Lista.NodoZonaTematica;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import zonaTematica.Atraccion;

public class VentanaAtraccion extends javax.swing.JFrame {

    VentanaPrincipal ventanaPrincipal;
    ListaZonaTematica listaZonaTematica;
    ListaAtraccion listaAtraccion;
    String arregloAtraccion[] = new String[8];
    DefaultTableModel modelo;
    int fila;
    String btn;
    public VentanaAtraccion(ListaZonaTematica listaZonaTematica, VentanaPrincipal ventanaPrincipal) {
        initComponents();
        this.ventanaPrincipal = ventanaPrincipal;
        this.listaZonaTematica = listaZonaTematica;
        estadosTxt(false);
        //listarTabla();
        listarCbZonaTematica();
        modelo = (DefaultTableModel) tablaAtraccion.getModel();
        this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    }
    public boolean listaVacia(){
        if(listaZonaTematica.getInicio().getEspectaculo().getInicio() == null){
            JOptionPane.showMessageDialog(null, "Lista vacia");
            return true;
        }
        return false;
    }
    public boolean filaEsMenoUno(){
        fila = tablaAtraccion.getSelectedRow();
        if(fila == -1){
            JOptionPane.showMessageDialog(null, "seleccion un elemento de la fila");
            return true;
        }
        return false;
    }
    public boolean unicoIdEditar(){
        int filaSeleccionada = 0;
        for(NodoZonaTematica auxNodoZonaTematica = listaZonaTematica.getInicio(); auxNodoZonaTematica != null; auxNodoZonaTematica = auxNodoZonaTematica.getSiguiente()){
            for(NodoAtraccion auxAtraccion = auxNodoZonaTematica.getAtraccion().getInicio(); auxAtraccion != null; auxAtraccion = auxAtraccion.getSiguiente()){
                if(auxAtraccion.getAtraccion().getIdAtraccion().equals(txtId.getText()) && fila != filaSeleccionada ){
                    JOptionPane.showMessageDialog(null, "inserte otro Id");
                    return false;
                }
                filaSeleccionada++;
            }
        }
        return true;
    }
    public boolean unicoNombreEditar(){
        int filaSeleccionada = 0;
        for(NodoZonaTematica auxNodoZonaTematica = listaZonaTematica.getInicio(); auxNodoZonaTematica != null; auxNodoZonaTematica = auxNodoZonaTematica.getSiguiente()){
            for(NodoAtraccion auxAtraccion = auxNodoZonaTematica.getAtraccion().getInicio(); auxAtraccion != null; auxAtraccion = auxAtraccion.getSiguiente()){
                if(auxAtraccion.getAtraccion().getIdAtraccion().equals(txtNombre.getText()) && fila != filaSeleccionada ){
                    JOptionPane.showMessageDialog(null, "inserte otro Id");
                    return false;
                }
                filaSeleccionada++;
            }
        }
        return true;
    }
    public boolean unicoId(){
        for(NodoZonaTematica auxNodoZonaTematica = listaZonaTematica.getInicio(); auxNodoZonaTematica != null; auxNodoZonaTematica = auxNodoZonaTematica.getSiguiente())
            for(NodoAtraccion auxAtraccion = auxNodoZonaTematica.getAtraccion().getInicio(); auxAtraccion != null; auxAtraccion = auxAtraccion.getSiguiente())
                if(auxAtraccion.getAtraccion().getIdAtraccion().equals(txtId.getText())){
                    JOptionPane.showMessageDialog(null, "inserte otro Id");
                    return false;
                }
        return true;
    }
    public boolean unicoNombre(){
        for(NodoZonaTematica auxNodoZonaTematica = listaZonaTematica.getInicio(); auxNodoZonaTematica != null; auxNodoZonaTematica = auxNodoZonaTematica.getSiguiente())
            for(NodoAtraccion auxAtraccion = auxNodoZonaTematica.getAtraccion().getInicio(); auxAtraccion != null; auxAtraccion = auxAtraccion.getSiguiente())
                if(auxAtraccion.getAtraccion().getIdAtraccion().equals(txtNombre.getText())){
                    JOptionPane.showMessageDialog(null, "inserte otro Id");
                    return false;
                }
        return true;
    }
    public void listarCbZonaTematica(){
        for(NodoZonaTematica auxZonaTematica = listaZonaTematica.getInicio(); auxZonaTematica != null; auxZonaTematica = auxZonaTematica.getSiguiente()){
            cbZonaTematica.addItem(auxZonaTematica.getZonaTematica().getNombre());
        }
    }
    public void listarTabla(){
        int cantidad = 1;
        modelo.setRowCount(0);
        for(NodoZonaTematica auxZonaTematica = listaZonaTematica.getInicio(); auxZonaTematica != null; auxZonaTematica = auxZonaTematica.getSiguiente()){
            for(NodoAtraccion auxAtraccion = auxZonaTematica.getAtraccion().getInicio(); auxAtraccion != null; auxAtraccion = auxAtraccion.getSiguiente()){
                arregloAtraccion[0] = Integer.toString(cantidad);
                arregloAtraccion[1] = auxAtraccion.getAtraccion().getIdAtraccion();
                arregloAtraccion[2] = auxAtraccion.getAtraccion().getNombre();
                arregloAtraccion[3] = Float.toString(auxAtraccion.getAtraccion().getEstaturaMinima());
                arregloAtraccion[4] = Float.toString(auxAtraccion.getAtraccion().getPrecio());
                arregloAtraccion[5] = Integer.toString(auxAtraccion.getAtraccion().getCapacidad());
                arregloAtraccion[6] = Float.toString(auxAtraccion.getAtraccion().getDuracion());
                arregloAtraccion[7] = auxZonaTematica.getZonaTematica().getNombre();
                modelo.addRow(arregloAtraccion);
                cantidad++; 
            }
        }
    }
    public void estadosTxt(boolean booleano){
        txtCapacidad.setEnabled(booleano);
        txtDuracion.setEnabled(booleano);
        txtEstatura.setEnabled(booleano);
        txtId.setEnabled(booleano);
        txtNombre.setEnabled(booleano);
        txtPrecio.setEnabled(booleano);
    }
    public void estadosBtn(boolean boolenao){
        btnGuardar.setEnabled(!boolenao);
        btnEditar.setEnabled(boolenao);
        btnEliminar.setEnabled(boolenao);
        btnNuevo.setEnabled(boolenao);
    }
    public boolean camposObligatoriosVacios(){
        if(txtCapacidad.getText().isEmpty() ||
                txtDuracion.getText().isEmpty() ||
                txtEstatura.getText().isEmpty() ||
                txtId.getText().isEmpty() ||
                txtNombre.getText().isEmpty() ||
                txtPrecio.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "rellene todos los campos");
            return true;
        }
        return false;
    }
    public void soloLetras(java.awt.event.KeyEvent evt){
        char validar = evt.getKeyChar();
        if(Character.isDigit(validar))
            evt.consume();
    }
    public void soloNumeros(java.awt.event.KeyEvent evt){
        char validar = evt.getKeyChar();
        if(Character.isLetter(validar))
            evt.consume();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaAtraccion = new javax.swing.JTable();
        txtDuracion = new javax.swing.JTextField();
        txtCapacidad = new javax.swing.JTextField();
        txtEstatura = new javax.swing.JTextField();
        txtNombre = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        cbZonaTematica = new javax.swing.JComboBox<>();
        btnNuevo = new javax.swing.JButton();
        btnEditar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnGuardar = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        txtId = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        txtPrecio = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setText("NOMBRE:");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(28, 96, -1, -1));

        jLabel2.setText("ESTATURA:");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(28, 122, -1, -1));

        jLabel3.setText("CAPACIDAD:");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(28, 174, -1, -1));

        jLabel4.setText("DURACION:");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(28, 200, -1, -1));

        tablaAtraccion.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "#", "CODIGO", "NOMBRE", "ESTATURA", "CAPACIDAD", "DURACION", "ZONA TEMATICA"
            }
        ));
        jScrollPane1.setViewportView(tablaAtraccion);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 238, 375, 233));

        txtDuracion.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtDuracionKeyTyped(evt);
            }
        });
        getContentPane().add(txtDuracion, new org.netbeans.lib.awtextra.AbsoluteConstraints(117, 197, 71, -1));

        txtCapacidad.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtCapacidadKeyTyped(evt);
            }
        });
        getContentPane().add(txtCapacidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(117, 171, 71, -1));

        txtEstatura.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtEstaturaKeyTyped(evt);
            }
        });
        getContentPane().add(txtEstatura, new org.netbeans.lib.awtextra.AbsoluteConstraints(117, 119, 71, -1));
        getContentPane().add(txtNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(117, 93, 71, -1));

        jLabel5.setText("ZONA TEMATICA");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(28, 44, -1, -1));

        getContentPane().add(cbZonaTematica, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 41, 91, -1));

        btnNuevo.setText("NUEVO");
        btnNuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuevoActionPerformed(evt);
            }
        });
        getContentPane().add(btnNuevo, new org.netbeans.lib.awtextra.AbsoluteConstraints(257, 67, 84, -1));

        btnEditar.setText("EDITAR");
        btnEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarActionPerformed(evt);
            }
        });
        getContentPane().add(btnEditar, new org.netbeans.lib.awtextra.AbsoluteConstraints(257, 108, 84, -1));

        btnEliminar.setText("ELIMINAR");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });
        getContentPane().add(btnEliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(257, 137, -1, -1));

        btnGuardar.setText("GUARDAR");
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });
        getContentPane().add(btnGuardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(257, 171, -1, -1));

        jLabel6.setText("ID");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(28, 70, -1, -1));
        getContentPane().add(txtId, new org.netbeans.lib.awtextra.AbsoluteConstraints(117, 67, 71, -1));

        jLabel7.setText("PRECIO:");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(28, 148, -1, -1));

        txtPrecio.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtPrecioKeyTyped(evt);
            }
        });
        getContentPane().add(txtPrecio, new org.netbeans.lib.awtextra.AbsoluteConstraints(117, 145, 71, -1));

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/honu-walkway-volcano-bay.jpg"))); // NOI18N
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 400, 480));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
        /*for(NodoZonaTematica auxZonaTematica = listaZonaTematica.getInicio(); auxZonaTematica != null; auxZonaTematica = auxZonaTematica.getSiguiente()){
            if(auxZonaTematica.getZonaTematica().getNombre().equals(cbZonaTematica.getSelectedItem())){
                listaAtraccion = auxZonaTematica.getAtraccion();
                listaAtraccion.agregarAdelante(new Atraccion(txtId.getText(), txtNombre.getText(), Float.parseFloat(txtEstatura.getText()), Float.parseFloat(txtPrecio.getText()), Integer.parseInt(txtCapacidad.getText()), Float.parseFloat(txtDuracion.getText())));
            }
        }
        listarTabla();*/
        if(camposObligatoriosVacios()) return;
        switch(btn){
            case ("NUEVO"):
                if(!unicoId() || !unicoNombre()) return;
                listaAtraccion = listaZonaTematica.listaAtraccion(cbZonaTematica.getSelectedItem().toString());
                listaAtraccion.agregarAdelante(new Atraccion(txtId.getText(), txtNombre.getText(), Float.parseFloat(txtEstatura.getText()), Float.parseFloat(txtPrecio.getText()), Integer.parseInt(txtCapacidad.getText()), Float.parseFloat(txtDuracion.getText())));
                break;
            case ("EDITAR"):
                if(!unicoIdEditar() || !unicoNombreEditar()) return;
                NodoAtraccion auxAtraccion = listaZonaTematica.listaAtraccion(cbZonaTematica.getSelectedItem().toString()).modificar(tablaAtraccion.getValueAt(fila, 1).toString());
                auxAtraccion.setAtraccion(new Atraccion(txtId.getText(), txtNombre.getText(), Float.parseFloat(txtEstatura.getText()), Float.parseFloat(txtPrecio.getText()), Integer.parseInt(txtCapacidad.getText()), Float.parseFloat(txtDuracion.getText())));
                break;
        }
        
        estadosTxt(false);
        listarTabla();
        estadosBtn(true);
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        if(listaZonaTematica.getInicio().getAtraccion().getInicio() == null) return;
        
        ventanaPrincipal.listarCbRestauranteEspectaculoAtraccion();
        ventanaPrincipal.estadoMenuAgregarCliente(true);
        
    }//GEN-LAST:event_formWindowClosing

    private void btnEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarActionPerformed
        if(listaVacia()) return;
        if(filaEsMenoUno())return;
        
        btn = "EDITAR";
        estadosTxt(true);
        estadosBtn(false);
    }//GEN-LAST:event_btnEditarActionPerformed

    private void btnNuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevoActionPerformed
        btn = "NUEVO";
        estadosTxt(true);
        estadosBtn(false); 
    }//GEN-LAST:event_btnNuevoActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        if(listaVacia()) return;
        if(filaEsMenoUno()) return;
        listaAtraccion = listaZonaTematica.listaAtraccion(cbZonaTematica.getSelectedItem().toString());
        listaAtraccion.eliminar(tablaAtraccion.getValueAt(fila, 1).toString());
        listarTabla();
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void txtPrecioKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtPrecioKeyTyped
        soloNumeros(evt);
    }//GEN-LAST:event_txtPrecioKeyTyped

    private void txtCapacidadKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCapacidadKeyTyped
        soloNumeros(evt);
    }//GEN-LAST:event_txtCapacidadKeyTyped

    private void txtDuracionKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtDuracionKeyTyped
        soloNumeros(evt);
    }//GEN-LAST:event_txtDuracionKeyTyped

    private void txtEstaturaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtEstaturaKeyTyped
        soloNumeros(evt);
    }//GEN-LAST:event_txtEstaturaKeyTyped

    /**
     * @param args the command line arguments
     */

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnEditar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnNuevo;
    private javax.swing.JComboBox<String> cbZonaTematica;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tablaAtraccion;
    private javax.swing.JTextField txtCapacidad;
    private javax.swing.JTextField txtDuracion;
    private javax.swing.JTextField txtEstatura;
    private javax.swing.JTextField txtId;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtPrecio;
    // End of variables declaration//GEN-END:variables
}
