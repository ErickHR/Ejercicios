
package Ventanas;

import Lista.ListaZonaTematica;
import Lista.ListaEspectaculo;
import Lista.NodoEspectaculo;
import Lista.NodoZonaTematica;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import zonaTematica.Espectaculo;

public class VentanaEspectaculo extends javax.swing.JFrame {

    VentanaPrincipal ventanaPrincipal;
    ListaZonaTematica listaZonaTematica;
    ListaEspectaculo listaEspectaculo;
    DefaultTableModel modelo;
    String arregloEspectaculo[] = new String[8]; 
    String btn;
    int fila;
    public VentanaEspectaculo(ListaZonaTematica lista, VentanaPrincipal ventanaPrincipal) {
        initComponents();
        this.ventanaPrincipal = ventanaPrincipal;
        
        this.listaZonaTematica = lista;
        modelo = (DefaultTableModel) tbEspectaculo.getModel();
        estadosTxt(false);
        estadoTxtAgregarTipo(false);
        listarCbZonaTematica();
        listarTabla();
        this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    }
    public void listarCbZonaTematica(){
        for(NodoZonaTematica auxZonaTematica = listaZonaTematica.getInicio(); auxZonaTematica != null; auxZonaTematica = auxZonaTematica.getSiguiente()){
            cbZonaTematica.addItem(auxZonaTematica.getZonaTematica().getNombre());
        }
    }
    public void listarTabla(){
        int cantidad = 1;
        modelo.setRowCount(0);
        for(NodoZonaTematica auxZonaTematica = listaZonaTematica.getInicio(); auxZonaTematica != null; auxZonaTematica = auxZonaTematica.getSiguiente()){
            for(NodoEspectaculo auxEspectaculo = auxZonaTematica.getEspectaculo().getInicio(); auxEspectaculo != null; auxEspectaculo = auxEspectaculo.getSiguiente()){
                arregloEspectaculo[0] = Integer.toString(cantidad);
                arregloEspectaculo[1] = auxEspectaculo.getEspectaculo().getIdEspectaculo();
                arregloEspectaculo[2] = auxEspectaculo.getEspectaculo().getNombre();
                arregloEspectaculo[3] = auxEspectaculo.getEspectaculo().getTipo();
                arregloEspectaculo[4] = Float.toString(auxEspectaculo.getEspectaculo().getPrecio());
                arregloEspectaculo[5] = Integer.toString(auxEspectaculo.getEspectaculo().getMinutos());
                arregloEspectaculo[6] = Integer.toString(auxEspectaculo.getEspectaculo().getAforoMaximo());
                arregloEspectaculo[7] = auxZonaTematica.getZonaTematica().getNombre();
                modelo.addRow(arregloEspectaculo);
                cantidad++; 
            }
        }
    }
    public void estadosTxt(boolean booleano){
        txtCodigo.requestFocus();
        txtCodigo.setEnabled(booleano);
        txtNombreEspectaculo.setEnabled(booleano);
        txtPrecio.setEnabled(booleano);
        spMinutos.setEnabled(booleano);
        spAforoMaximo.setEnabled(booleano);
    }
    public void estadoTxtAgregarTipo(boolean booleano){
        txtAgregarTipoEspectaculo.setEnabled(booleano);
    }
    public void modificarTxt(String codigo, String nombre,String precio, int minutos, int aforo){
        txtCodigo.setText(codigo);
        txtNombreEspectaculo.setText(nombre);
        txtPrecio.setText(precio);
        //cbTipoEspectaculo.setSelectedItem(tipo);
        spMinutos.setValue(0);
        spAforoMaximo.setValue(aforo);
    }
    public boolean camposObligatoriosVacios(){
        if(txtCodigo.getText().isEmpty()){
            txtCodigo.requestFocus();
            JOptionPane.showMessageDialog(null, "FALTA RELLENAR CAMPO CODIGO");
            return true;
        }
        if(txtNombreEspectaculo.getText().isEmpty()){
            txtNombreEspectaculo.requestFocus();
            JOptionPane.showMessageDialog(null, "FALTA RELLENAR CAMPO NOMBRE");
            return true;
        }
        if(Integer.parseInt(spMinutos.getValue().toString()) < 30){
            JOptionPane.showMessageDialog(null, "MINUTOS MAYOR A 30");
            spMinutos.setValue(30);
            return true;
        }
        
        if(Integer.parseInt(spAforoMaximo.getValue().toString()) < 5){
            JOptionPane.showMessageDialog(null, "AFORO MAYOR A 5");
            spAforoMaximo.setValue(5);
            return true;
        }
        return false;
    }
    public void estadosBtn(boolean boolenao){
        btnGuardar.setEnabled(!boolenao);
        btnEditar.setEnabled(boolenao);
        btnEliminar.setEnabled(boolenao);
        btnNuevo.setEnabled(boolenao);
    }
    public void soloLetras(java.awt.event.KeyEvent evt){
        char validar = evt.getKeyChar();
        if(Character.isDigit(validar))
            evt.consume();
    }
    public void soloNumeros(java.awt.event.KeyEvent evt){
        char validar = evt.getKeyChar();
        if(Character.isLetter(validar)){
            evt.consume();
        }
    }
    public boolean unicoIdEditar(){
        int filaSeleccionada = 0;
        for(NodoZonaTematica auxNodoZonaTematica = listaZonaTematica.getInicio(); auxNodoZonaTematica != null; auxNodoZonaTematica = auxNodoZonaTematica.getSiguiente()){
            for(NodoEspectaculo auxEspectaculo = auxNodoZonaTematica.getEspectaculo().getInicio(); auxEspectaculo != null; auxEspectaculo = auxEspectaculo.getSiguiente()){
                if(auxEspectaculo.getEspectaculo().getIdEspectaculo().equals(txtCodigo.getText()) && fila != filaSeleccionada ){
                    JOptionPane.showMessageDialog(null, "inserte otro Id");
                    return false;
                }
                filaSeleccionada++;
            }
        }
        return true;
    }
    public boolean unicoNombreEditar(){
        int filaSeleccionada = 0;
        for(NodoZonaTematica auxNodoZonaTematica = listaZonaTematica.getInicio(); auxNodoZonaTematica != null; auxNodoZonaTematica = auxNodoZonaTematica.getSiguiente()){
            for(NodoEspectaculo auxEspectaculo = auxNodoZonaTematica.getEspectaculo().getInicio(); auxEspectaculo != null; auxEspectaculo = auxEspectaculo.getSiguiente()){
                if(auxEspectaculo.getEspectaculo().getIdEspectaculo().equals(txtNombreEspectaculo.getText()) && fila != filaSeleccionada ){
                    JOptionPane.showMessageDialog(null, "inserte otro Id");
                    return false;
                }
                filaSeleccionada++;
            }
        }
        return true;
    }
    public boolean unicoId(){
        for(NodoZonaTematica auxNodoZonaTematica = listaZonaTematica.getInicio(); auxNodoZonaTematica != null; auxNodoZonaTematica = auxNodoZonaTematica.getSiguiente())
            for(NodoEspectaculo auxEspectaculo = auxNodoZonaTematica.getEspectaculo().getInicio(); auxEspectaculo != null; auxEspectaculo = auxEspectaculo.getSiguiente())
                if(auxEspectaculo.getEspectaculo().getIdEspectaculo().equals(txtCodigo.getText())){
                    JOptionPane.showMessageDialog(null, "inserte otro codigo");
                    return false;
                }
        return true;
    }
    public boolean unicoNombre(){
        for(NodoZonaTematica auxNodoZonaTematica = listaZonaTematica.getInicio(); auxNodoZonaTematica != null; auxNodoZonaTematica = auxNodoZonaTematica.getSiguiente())
            for(NodoEspectaculo auxEspectaculo = auxNodoZonaTematica.getEspectaculo().getInicio(); auxEspectaculo != null; auxEspectaculo = auxEspectaculo.getSiguiente())
                if(auxEspectaculo.getEspectaculo().getIdEspectaculo().equals(txtNombreEspectaculo.getText())){
                    JOptionPane.showMessageDialog(null, "inserte otro nombre");
                    return false;
                }
        return true;
    }
    public boolean listaVacia(){
        if(listaZonaTematica.getInicio().getEspectaculo().getInicio() == null){
            JOptionPane.showMessageDialog(null, "Lista vacia");
            return true;
        }
        return false;
    }
    public boolean filaEsMenoUno(){
        fila = tbEspectaculo.getSelectedRow();
        if(fila == -1){
            JOptionPane.showMessageDialog(null, "seleccion un elemento de la fila");
            return true;
        }
        return false;
    }
    public boolean noSeleccionoFila(){
        if(fila == -1){
            JOptionPane.showMessageDialog(null, "seleccione un elemento de la fila");
            return true;
        }
        return false;
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        cbTipoEspectaculo = new javax.swing.JComboBox<>();
        txtNombreEspectaculo = new javax.swing.JTextField();
        txtAgregarTipoEspectaculo = new javax.swing.JTextField();
        btnGuardar = new javax.swing.JButton();
        btnAgregarTipoEspectaculo = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txtCodigo = new javax.swing.JTextField();
        jScrollPane4 = new javax.swing.JScrollPane();
        tbEspectaculo = new javax.swing.JTable();
        jLabel6 = new javax.swing.JLabel();
        btnNuevo = new javax.swing.JButton();
        btnEditar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        spMinutos = new javax.swing.JSpinner();
        jLabel7 = new javax.swing.JLabel();
        cbZonaTematica = new javax.swing.JComboBox<>();
        jLabel8 = new javax.swing.JLabel();
        txtPrecio = new javax.swing.JTextField();
        spAforoMaximo = new javax.swing.JSpinner();
        jLabel9 = new javax.swing.JLabel();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(jTable2);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosed(java.awt.event.WindowEvent evt) {
                formWindowClosed(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("NOMBRE:");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 104, -1, -1));

        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("TIPO:");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 130, -1, -1));

        jLabel3.setText("MINUTOS:");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 182, -1, -1));

        cbTipoEspectaculo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "musica", "danza", "teatro" }));
        getContentPane().add(cbTipoEspectaculo, new org.netbeans.lib.awtextra.AbsoluteConstraints(133, 127, 118, -1));

        txtNombreEspectaculo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtNombreEspectaculoKeyTyped(evt);
            }
        });
        getContentPane().add(txtNombreEspectaculo, new org.netbeans.lib.awtextra.AbsoluteConstraints(133, 101, 118, -1));
        getContentPane().add(txtAgregarTipoEspectaculo, new org.netbeans.lib.awtextra.AbsoluteConstraints(133, 232, 114, -1));

        btnGuardar.setText("GUARDAR");
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });
        getContentPane().add(btnGuardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(281, 162, 91, -1));

        btnAgregarTipoEspectaculo.setText("AGREGAR TIPO");
        btnAgregarTipoEspectaculo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarTipoEspectaculoActionPerformed(evt);
            }
        });
        getContentPane().add(btnAgregarTipoEspectaculo, new org.netbeans.lib.awtextra.AbsoluteConstraints(269, 231, -1, -1));

        jLabel4.setText("AFORO MAXIMO:");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 208, -1, -1));

        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("CODIGO:");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 78, -1, -1));
        getContentPane().add(txtCodigo, new org.netbeans.lib.awtextra.AbsoluteConstraints(133, 75, 122, -1));

        tbEspectaculo.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "#", "CODIGO", "NOMBRE", "TIPO", "PRECIO", "MINUTOS", "AFORO", "ZONA TEMATICA"
            }
        ));
        jScrollPane4.setViewportView(tbEspectaculo);

        getContentPane().add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 272, 375, 233));

        jLabel6.setText("AGREGAR TIPO:");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 235, -1, -1));

        btnNuevo.setText("NUEVO");
        btnNuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuevoActionPerformed(evt);
            }
        });
        getContentPane().add(btnNuevo, new org.netbeans.lib.awtextra.AbsoluteConstraints(281, 75, 91, -1));

        btnEditar.setText("EDITAR");
        btnEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarActionPerformed(evt);
            }
        });
        getContentPane().add(btnEditar, new org.netbeans.lib.awtextra.AbsoluteConstraints(281, 104, 91, -1));

        btnEliminar.setText("ELIMINAR");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });
        getContentPane().add(btnEliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(281, 133, 91, -1));
        getContentPane().add(spMinutos, new org.netbeans.lib.awtextra.AbsoluteConstraints(133, 179, 79, -1));

        jLabel7.setForeground(new java.awt.Color(255, 0, 0));
        jLabel7.setText("ZonaTematica");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 31, 80, 20));

        getContentPane().add(cbZonaTematica, new org.netbeans.lib.awtextra.AbsoluteConstraints(133, 28, 122, -1));

        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("PRECIO:");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 151, -1, -1));

        txtPrecio.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtPrecioKeyTyped(evt);
            }
        });
        getContentPane().add(txtPrecio, new org.netbeans.lib.awtextra.AbsoluteConstraints(133, 148, 118, -1));
        getContentPane().add(spAforoMaximo, new org.netbeans.lib.awtextra.AbsoluteConstraints(132, 205, 80, -1));

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/espectaculo.jpg"))); // NOI18N
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(-190, -10, 680, 520));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
        
        if(camposObligatoriosVacios()) return;
        switch(btn){
            case ("NUEVO"):
                if(!unicoId() || !unicoNombre()) return;
                listaEspectaculo = listaZonaTematica.listaEspectaculo(cbZonaTematica.getSelectedItem().toString());
                listaEspectaculo.agregarAdelante(new Espectaculo(txtCodigo.getText(), txtNombreEspectaculo.getText(), cbTipoEspectaculo.getSelectedItem().toString(), Float.parseFloat(txtPrecio.getText()), Integer.parseInt(spMinutos.getValue().toString()), Integer.parseInt(spAforoMaximo.getValue().toString())));
                break;
            case ("EDITAR"):
                if(!unicoIdEditar() || !unicoNombreEditar()) return;
                NodoEspectaculo auxesEspectaculo = listaZonaTematica.listaEspectaculo(cbZonaTematica.getSelectedItem().toString()).modificar(tbEspectaculo.getValueAt(fila, 1).toString());
                auxesEspectaculo.setEspectaculo(new Espectaculo(txtCodigo.getText(), txtNombreEspectaculo.getText(), cbTipoEspectaculo.getSelectedItem().toString(), Float.parseFloat(txtPrecio.getText()), Integer.parseInt(spMinutos.getValue().toString()), Integer.parseInt(spAforoMaximo.getValue().toString())));
                break;
        }
        
        modificarTxt("", "","", 0, 0);
        estadosTxt(false);
        listarTabla();
        estadosBtn(true);
        
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void btnAgregarTipoEspectaculoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarTipoEspectaculoActionPerformed
        // TODO add your handling code here:
        btnAgregarTipoEspectaculo.setText("GUARDAR TIPO");
        estadoTxtAgregarTipo(true);
        if(txtAgregarTipoEspectaculo.getText().isEmpty()) return;
        cbTipoEspectaculo.addItem(txtAgregarTipoEspectaculo.getText());
        txtAgregarTipoEspectaculo.setText("");
        estadoTxtAgregarTipo(false);
        btnAgregarTipoEspectaculo.setText("AGREGAR TIPO");
    }//GEN-LAST:event_btnAgregarTipoEspectaculoActionPerformed

    private void btnNuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevoActionPerformed
        btn = "NUEVO";
        estadosTxt(true);
        estadosBtn(false);       
    }//GEN-LAST:event_btnNuevoActionPerformed

    private void btnEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarActionPerformed
        if(listaVacia()) return;
        if(filaEsMenoUno())return;
        
        btn = "EDITAR";
        /*
        modificarTxt(tbEspectaculo.getValueAt(fila, 1).toString(),
                tbEspectaculo.getValueAt(fila, 2).toString() , 
                tbEspectaculo.getValueAt(fila, 3).toString(), 
                Integer.parseInt(tbEspectaculo.getValueAt(fila, 4).toString()), 
                Integer.parseInt(tbEspectaculo.getValueAt(fila, 5).toString()));
                */
        estadosTxt(true);
        estadosBtn(false);
        
    }//GEN-LAST:event_btnEditarActionPerformed

    private void txtNombreEspectaculoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNombreEspectaculoKeyTyped
        // TODO add your handling code here:
        soloLetras(evt);
    }//GEN-LAST:event_txtNombreEspectaculoKeyTyped

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        if(listaVacia()) return;
        if(filaEsMenoUno()) return;
        listaEspectaculo = listaZonaTematica.listaEspectaculo(cbZonaTematica.getSelectedItem().toString());
        listaEspectaculo.eliminar(tbEspectaculo.getValueAt(fila, 1).toString());
        listarTabla();
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void formWindowClosed(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosed
        if(listaZonaTematica.getInicio().getEspectaculo().getInicio() == null) return;
        ventanaPrincipal.listarCbRestauranteEspectaculoAtraccion();
        ventanaPrincipal.estadoMenuAgregarCliente(true);
        
    }//GEN-LAST:event_formWindowClosed

    private void txtPrecioKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtPrecioKeyTyped
        soloNumeros(evt);
    }//GEN-LAST:event_txtPrecioKeyTyped


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAgregarTipoEspectaculo;
    private javax.swing.JButton btnEditar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnNuevo;
    private javax.swing.JComboBox<String> cbTipoEspectaculo;
    private javax.swing.JComboBox<String> cbZonaTematica;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JSpinner spAforoMaximo;
    private javax.swing.JSpinner spMinutos;
    private javax.swing.JTable tbEspectaculo;
    private javax.swing.JTextField txtAgregarTipoEspectaculo;
    private javax.swing.JTextField txtCodigo;
    private javax.swing.JTextField txtNombreEspectaculo;
    private javax.swing.JTextField txtPrecio;
    // End of variables declaration//GEN-END:variables
}
